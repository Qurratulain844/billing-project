from rest_framework import serializers
from django.db import transaction
from .models import Invoice, InvoiceItem


class InvoiceItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = InvoiceItem
        fields = ['product_variant', 'quantity']


class InvoiceSerializer(serializers.ModelSerializer):
    items = InvoiceItemSerializer(many=True)

    class Meta:
        model = Invoice
        fields = [
            'id',
            'invoice_number',
            'customer',
            'date',
            'gst_percent',
            'subtotal',
            'gst_amount',
            'total_amount',
            'payment_status',
            'items'
        ]
        read_only_fields = ['invoice_number', 'subtotal', 'gst_amount', 'total_amount']

    def create(self, validated_data):
        items_data = validated_data.pop('items')

        with transaction.atomic():

            invoice = Invoice.objects.create(**validated_data)

            for item_data in items_data:
                InvoiceItem.objects.create(
                    invoice=invoice,
                    **item_data
                )

        return invoice
