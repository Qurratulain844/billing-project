from django.urls import path
from .views import UpdateAccountView, LoginView,LogoutView
urlpatterns = [
    path("login/", LoginView.as_view()),
    path("logout/", LogoutView.as_view()),
    path("settings/", UpdateAccountView.as_view()),
]